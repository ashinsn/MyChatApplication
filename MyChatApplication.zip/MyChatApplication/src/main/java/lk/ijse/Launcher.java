package lk.ijse;

import lk.ijse.server.ServerLauncher;

public class Launcher {
    public static void main(String[] args) {
        ServerLauncher.main(new String[]{});
    }
}
